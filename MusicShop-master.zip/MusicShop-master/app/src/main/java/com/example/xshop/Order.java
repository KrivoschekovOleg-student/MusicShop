package com.example.xshop;

public class Order {
    String userName;
    String goodsName;
    int quantity;
    double price;
    double orderPrice;
}
